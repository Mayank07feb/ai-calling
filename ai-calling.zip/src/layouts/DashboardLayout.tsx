import React from 'react';
import { Outlet } from 'react-router-dom';
import DashboardHeader from '../components/DashboardHeader.js';
import DashboardFooter from '../components/DashboardFooter.js';

const DashboardLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <DashboardHeader />

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      <DashboardFooter />
    </div>
  );
};

export default DashboardLayout;
