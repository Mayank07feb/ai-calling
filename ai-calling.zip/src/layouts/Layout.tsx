import { Outlet } from "react-router-dom";
import Header from "../components/Header.js";
// import Footer from "../components/Footer.js"; 

const Layout = () => {
  return (
    <div className="min-h-screen flex flex-col bg-secondary">

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-1 mx-auto w-full py-10">
        <Outlet />
      </main>

      {/* Footer hidden */}
      {/* <Footer /> */}

    </div>
  );
};

export default Layout;
