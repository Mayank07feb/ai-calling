import React from 'react';
import { CheckCircleIcon } from '@heroicons/react/24/solid';

const ProfilePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 lg:p-8 mb-6 sm:mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 sm:gap-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 text-center sm:text-left">
              <div className="w-20 h-20 sm:w-24 sm:h-24 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-2xl sm:text-4xl">SY</span>
              </div>
              <div className="flex-1">
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Sony Yadav</h1>
                <p className="text-gray-600 mb-3 sm:mb-4 text-sm sm:text-base">sonyyada101@gmail.com</p>
                <div className="flex flex-wrap justify-center sm:justify-start gap-4 sm:gap-6 lg:gap-8">
                  <div className="text-center sm:text-left">
                    <p className="text-xs sm:text-sm text-gray-600 mb-1">MEMBER SINCE</p>
                    <p className="text-orange-500 font-semibold text-sm sm:text-base">2025</p>
                  </div>
                  <div className="text-center sm:text-left">
                    <p className="text-xs sm:text-sm text-gray-600 mb-1">EMAIL STATUS</p>
                    <div className="flex justify-center sm:justify-start items-center gap-1">
                      <CheckCircleIcon className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
                      <span className="text-orange-500 font-semibold text-sm sm:text-base">Verified</span>
                    </div>
                  </div>
                  <div className="text-center sm:text-left">
                    <p className="text-xs sm:text-sm text-gray-600 mb-1">ACCOUNT STATUS</p>
                    <p className="text-orange-500 font-semibold text-sm sm:text-base">Active</p>
                  </div>
                </div>
              </div>
            </div>
            <button className="px-4 sm:px-6 py-2 sm:py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors text-sm sm:text-base w-full sm:w-auto">
              Edit Profile
            </button>
          </div>
        </div>

        {/* Personal Information */}
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 lg:p-8">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">Personal Information</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            <div className="bg-purple-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">FULL NAME</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500">Sony Yadav</p>
            </div>

            <div className="bg-purple-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">EMAIL ADDRESS</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500 break-all">sonyyada101@gmail.com</p>
            </div>

            <div className="bg-orange-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">ACCOUNT STATUS</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500">ACTIVE</p>
            </div>

            <div className="bg-orange-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">EMAIL VERIFIED</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500">VERIFIED</p>
            </div>

            <div className="bg-purple-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">MEMBER SINCE</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500">November 10, 2025</p>
            </div>

            <div className="bg-purple-50 rounded-lg p-4 sm:p-6">
              <p className="text-xs sm:text-sm font-medium text-gray-600 mb-2">LAST LOGIN</p>
              <p className="text-base sm:text-lg font-semibold text-orange-500">November 12, 2025 9:39 AM</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;