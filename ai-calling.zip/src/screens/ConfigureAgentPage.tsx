import React, { useState } from 'react';
import { ChevronDownIcon, CalendarIcon } from '@heroicons/react/24/outline';

const ConfigureAgentPage: React.FC = () => {
  const [formData, setFormData] = useState({
    businessName: 'No Onion No Garlic (NONG)',
    industry: 'Food & Lifestyle Platform',
    phone: '',
    email: '',
    address: '',
    businessDescription: 'A one-stop destination for pure, sattvic living, offering recipes, certified products, and restaurant listings that are 100% free of onion and garlic, and are often Jain-friendly.',
    servicesOffered: `['No onion no garlic recipes', 'Handpicked NONG-certified products', 'Listings of trusted restaurants serving Jain-friendly meals', 'Personalized sattvic recommendations', 'User accounts to save recipes and track orders']`,
    additionalInfo: 'The platform targets home cooks and food lovers who follow a sattvic or onion/garlic-free diet. Slogan: \'Pure taste. Pure trust. Pure NONG.\'',
    agentName: 'AI Agent',
    primaryLanguage: 'English',
    voice: '',
    personality: 'Friendly and Helping',
    workingHours: '09:00 AM - 06:00 PM',
    firstMessage: "Hello! I'm your AI assistant. How can you help I today?"
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Steps - Mobile responsive */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 mb-6 sm:mb-8">
          <span className="px-3 py-1 sm:px-4 sm:py-2 bg-orange-500 text-white rounded-full text-xs sm:text-sm font-medium">
            Website Analysis
          </span>
          <span className="px-3 py-1 sm:px-4 sm:py-2 bg-orange-100 text-orange-600 rounded-full text-xs sm:text-sm font-medium">
            AI Configuration
          </span>
          <span className="px-3 py-1 sm:px-4 sm:py-2 bg-gray-200 text-gray-600 rounded-full text-xs sm:text-sm font-medium">
            Test Agent
          </span>
          <span className="px-3 py-1 sm:px-4 sm:py-2 bg-gray-200 text-gray-600 rounded-full text-xs sm:text-sm font-medium">
            Go Live
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 text-center mb-6 sm:mb-8">
          Configure Your AI Agent
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
          {/* Left Column - Business Information */}
          <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-4 sm:mb-6">Business Information</h2>
            <div className="space-y-4">
              {/* Business Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Business Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                />
              </div>

              {/* Industry */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Industry
                </label>
                <input
                  type="text"
                  value={formData.industry}
                  onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                />
              </div>

              {/* Phone & Email - Stack on mobile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                  />
                </div>
              </div>

              {/* Address */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Address
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                />
              </div>

              {/* Business Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Business Description
                </label>
                <textarea
                  value={formData.businessDescription}
                  onChange={(e) => setFormData({ ...formData, businessDescription: e.target.value })}
                  rows={4}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base resize-vertical"
                />
              </div>

              {/* Services Offered */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Services Offered
                </label>
                <textarea
                  value={formData.servicesOffered}
                  onChange={(e) => setFormData({ ...formData, servicesOffered: e.target.value })}
                  rows={4}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base resize-vertical"
                />
              </div>

              {/* Additional Info */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Additional Information
                </label>
                <textarea
                  value={formData.additionalInfo}
                  onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
                  rows={4}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base resize-vertical"
                />
              </div>
            </div>
          </div>

          {/* Right Column - AI Agent Configuration */}
          <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-4 sm:mb-6">AI Agent Configuration</h2>
            <div className="space-y-4">
              {/* Agent Name & Language - Stack on mobile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Agent Name
                  </label>
                  <input
                    type="text"
                    value={formData.agentName}
                    onChange={(e) => setFormData({ ...formData, agentName: e.target.value })}
                    className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Primary Language
                  </label>
                  <div className="relative">
                    <select
                      value={formData.primaryLanguage}
                      onChange={(e) => setFormData({ ...formData, primaryLanguage: e.target.value })}
                      className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none text-sm sm:text-base"
                    >
                      <option>English</option>
                      <option>Spanish</option>
                      <option>French</option>
                    </select>
                    <ChevronDownIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              {/* ElevenLabs Voice - Stack preview button on mobile */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ElevenLabs Voice
                  </label>
                  <div className="relative">
                    <select
                      value={formData.voice}
                      onChange={(e) => setFormData({ ...formData, voice: e.target.value })}
                      className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none text-sm sm:text-base text-gray-400"
                    >
                      <option>-- Select a voice --</option>
                    </select>
                    <ChevronDownIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <button className="sm:mt-7 px-4 sm:px-6 py-2 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors text-sm sm:text-base">
                  Preview
                </button>
              </div>

              {/* Personality, Working Hours, First Message */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Agent Personality
                </label>
                <textarea
                  value={formData.personality}
                  onChange={(e) => setFormData({ ...formData, personality: e.target.value })}
                  rows={3}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base resize-vertical"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Working Hours
                </label>
                <input
                  type="text"
                  value={formData.workingHours}
                  onChange={(e) => setFormData({ ...formData, workingHours: e.target.value })}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Agent First Message
                </label>
                <textarea
                  value={formData.firstMessage}
                  onChange={(e) => setFormData({ ...formData, firstMessage: e.target.value })}
                  rows={3}
                  className="w-full px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base resize-vertical"
                />
              </div>

              {/* Google Calendar Integration */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mt-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 gap-2">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-5 h-5 sm:w-6 sm:h-6 text-orange-500" />
                    <span className="font-semibold text-gray-900 text-sm sm:text-base">Google Calendar Integration</span>
                  </div>
                  <span className="self-start sm:self-auto px-2 py-1 bg-blue-500 text-white text-xs font-semibold rounded-full">
                    PREMIUM
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-gray-700 space-y-1">
                  <p className="font-medium text-orange-700 mb-2">To connect your Google Calendar:</p>
                  <p>1. Complete the agent setup process</p>
                  <p>2. Go to your <span className="font-semibold text-orange-600">Agent Details</span> page</p>
                  <p>3. Click the <span className="font-semibold text-orange-600">"Connect Google Calendar"</span> button</p>
                  <p>4. Authorize the integration with your Google account</p>
                </div>
              </div>
            </div>

            {/* Action Buttons - Stack on mobile */}
            <div className="flex flex-col sm:flex-row gap-3 mt-6 sm:mt-8">
              <button className="px-4 sm:px-6 py-2 sm:py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors text-sm sm:text-base">
                Back
              </button>
              <button className="px-4 sm:px-6 py-2 sm:py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors text-sm sm:text-base">
                Save & Continue
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ConfigureAgentPage;