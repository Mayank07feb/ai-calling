import React from "react";
import {
  MagnifyingGlassCircleIcon,
  AdjustmentsHorizontalIcon,
  BoltIcon,
  RocketLaunchIcon,
} from "@heroicons/react/24/outline";

interface Step {
  number: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
}

const steps: Step[] = [
  {
    number: "01",
    title: "Analyze Your Website",
    desc: "Our AI reviews your web content, learning about your services and audiences for tailored agent responses.",
    icon: <MagnifyingGlassCircleIcon className="h-10 w-10 text-orange-500" />,
  },
  {
    number: "02",
    title: "Customize Your Agent",
    desc: "Design agent personality, tone, and logic—set rules for business requirements, branding, and desired outcomes.",
    icon: <AdjustmentsHorizontalIcon className="h-10 w-10 text-orange-500" />,
  },
  {
    number: "03",
    title: "Test Your Agent",
    desc: "Instantly test and preview your AI agent, adjusting instructions and reviewing response accuracy live.",
    icon: <BoltIcon className="h-10 w-10 text-orange-500" />,
  },
  {
    number: "04",
    title: "Go Live Instantly",
    desc: "Connect agents to your calls, chat, or support tools using secure API/webhook integration with one click.",
    icon: <RocketLaunchIcon className="h-10 w-10 text-orange-500" />,
  },
];

const Home: React.FC = () => {
  return (
    <div className="w-full font-sans bg-gray-100">

      {/* HERO SECTION */}
      <section className="flex flex-col-reverse lg:flex-row items-center justify-between px-6 md:px-16 lg:px-10 py-12 lg:py-24 gap-10 animate-fade-in-up">
        {/* LEFT CONTENT */}
        <div className="max-w-2xl text-center lg:text-left space-y-6">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight text-gray-900 animate-fade-in-up">
            Create AI Calling Agents{" "}
            <span className="text-purple-400">In 4 Simple Steps</span>
          </h1>

          <p className="text-md sm:text-lg text-gray-600 leading-relaxed animate-fade-in-up delay-100">
            Build custom AI Agents with unique personalities and connect them to your customers via calls or webhook. Transform your customer conversation experience in minutes.
          </p>

          {/* Buttons */}
          <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-fade-in-up delay-200">
            <button className="bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition shadow-lg font-medium">
              Start Building Free
            </button>
            <button className="px-8 py-3 rounded-lg border-2 border-gray-300 text-gray-700 hover:bg-gray-100 transition font-medium">
              Learn More
            </button>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-4 mt-8 justify-center lg:justify-start animate-fade-in-up delay-300">
            <span className="bg-white px-5 py-3 rounded-lg text-gray-800 shadow border border-gray-200">
              10K+ Users
            </span>
            <span className="bg-white px-5 py-3 rounded-lg text-gray-800 shadow border border-gray-200">
              99.9% Uptime
            </span>
            <span className="bg-white px-5 py-3 rounded-lg text-gray-800 shadow border border-gray-200">
              24/7 Support
            </span>
          </div>
        </div>

        {/* RIGHT IMAGE */}
        <div className="relative w-full max-w-md lg:max-w-lg animate-fade-in-up delay-400">
          <div className="bg-gradient-to-br from-blue-900 to-purple-900 rounded-3xl p-8 sm:p-12 shadow-2xl w-full">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-t from-cyan-400/20 to-transparent rounded-2xl blur-2xl"></div>
              <img
                src="https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=600&q=80"
                className="relative rounded-2xl shadow-xl opacity-90"
                alt="AI Phone"
              />
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-24 h-24 bg-cyan-400 rounded-full blur-3xl opacity-60 animate-pulse"></div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-4 right-4 bg-gray-900 text-white px-4 py-2 rounded-full text-xs font-medium shadow-lg">
            Edit with ❤️ Lovable
          </div>
        </div>
      </section>

      {/* 4 STEPS SECTION */}
      <section className="px-6 md:px-16 lg:px-12 py-16 bg-white">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-center text-gray-800 animate-fade-in-up">
          Your AI Agent in <span className="text-purple-400">4 Simple Steps</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12 max-w-7xl mx-auto">
          {steps.map((step, index) => (
            <div
              key={index}
              className="rounded-lg border text-gray-800 shadow-sm relative p-6 sm:p-8 bg-white
              border-gray-200 hover:shadow-lg transition-all duration-500 
              hover:border-orange-500/40 hover:-translate-y-2 group animate-fade-in-up"
              style={{ animationDelay: `${index * 0.15}s`, animationFillMode: "backwards" }}
            >
              {/* Number Badge */}
              <div className="absolute top-4 right-4">
                <div className="w-12 h-12 rounded-lg bg-orange-100/20 flex items-center justify-center 
                  group-hover:bg-orange-100/30 transition-all duration-300 group-hover:scale-110">
                  <span className="text-lg font-bold text-orange-500">{step.number}</span>
                </div>
              </div>

              {/* Icon */}
              <div className="mb-4 group-hover:scale-110 transition-transform duration-300">
                {step.icon}
              </div>

              <h3 className="text-lg sm:text-xl font-bold mb-2">{step.title}</h3>
              <p className="text-gray-600 text-sm sm:text-base leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="px-6 md:px-16 lg:px-24 py-16 bg-gray-50">
        <div className="max-w-5xl mx-auto bg-gradient-to-br from-purple-50 to-pink-50 p-8 sm:p-12 lg:p-16 rounded-3xl text-center shadow-xl border border-purple-100 animate-fade-in-up">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">
            Ready to Transform Your <span className="text-purple-400">Customer Experience?</span>
          </h2>

          <p className="mt-6 text-md sm:text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Join thousands of businesses using AI agents to automate conversations, boost efficiency, and delight customers 24/7.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition shadow-lg font-medium">
              Start Building Free
            </button>
            <button className="px-8 py-3 rounded-lg border-2 border-gray-300 bg-white text-gray-700 hover:bg-gray-50 transition font-medium shadow">
              Schedule a Demo
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
