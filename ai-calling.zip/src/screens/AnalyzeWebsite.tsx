import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChatBubbleLeftRightIcon, UsersIcon, PlusIcon, Cog6ToothIcon } from '@heroicons/react/24/outline';

const AnalyzeWebsite: React.FC = () => {
  const navigate = useNavigate();

  const [websiteUrl, setWebsiteUrl] = useState('https://example.com');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { label: 'Analyzing your website...', color: 'text-orange-500', bgColor: 'bg-orange-500' },
    { label: 'Extracting Website Data', color: 'text-green-500', bgColor: 'bg-green-500' },
    { label: 'Passing Website Data', color: 'text-blue-500', bgColor: 'bg-blue-500' },
  ];

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setCurrentStep(0);
  };

  useEffect(() => {
    if (!isAnalyzing) return;

    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < steps.length - 1) return prev + 1;

        clearInterval(interval);
        setTimeout(() => {
          setIsAnalyzing(false);
          navigate('/configure-agent'); // Navigate after analysis
        }, 1000);

        return prev;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isAnalyzing, navigate]);

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Launch Your <span className="text-orange-500">AI Receptionist</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-600">
            Transform your business communications in minutes
          </p>
        </div>

        {/* Steps */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <span className="px-4 py-2 bg-orange-100 text-orange-600 rounded-full text-sm font-medium">
            Website Analysis
          </span>
          <span
            className="px-4 py-2 bg-orange-500 text-white rounded-full text-sm font-medium cursor-pointer hover:scale-105 transition-transform"
            onClick={() => navigate('/configure-agent')}
          >
            AI Configuration
          </span>
          <span className="px-4 py-2 bg-orange-500 text-white rounded-full text-sm font-medium">
            Test Agent
          </span>
          <span className="px-4 py-2 bg-orange-500 text-white rounded-full text-sm font-medium">
            Go Live
          </span>
        </div>

        {/* Input Section */}
        <div className="bg-white rounded-2xl shadow-lg p-6 sm:p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Enter Your Business Website
          </h2>
          <p className="text-gray-600 mb-6">
            Our AI will analyze and configure your receptionist
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <input
              type="url"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              placeholder="https://example.com"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
            <button
              onClick={handleAnalyze}
              className="px-8 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              Analyze Website
            </button>
          </div>
        </div>

        {/* Features Section */}
        <div>
          <h3 className="text-2xl font-bold text-orange-500 mb-6">
            Why Receptionista?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="text-lg font-bold text-orange-500 mb-2">Smart Analysis</h4>
              <p className="text-gray-600">AI understands your business context</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="text-lg font-bold text-orange-500 mb-2">2-Minute Setup</h4>
              <p className="text-gray-600">Quick and easy configuration</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="text-lg font-bold text-orange-500 mb-2">Enterprise Ready</h4>
              <p className="text-gray-600">Secure and scalable</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="text-lg font-bold text-orange-500 mb-2">24/7 Available</h4>
              <p className="text-gray-600">Never miss a customer call</p>
            </div>
          </div>
        </div>
      </main>

      {/* Modal Overlay */}
      {isAnalyzing && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl p-6 sm:p-8 max-w-md w-full mx-4 animate-fade-in">
            {/* Robot Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-white rounded-full border-4 border-orange-500 flex items-center justify-center">
                <Cog6ToothIcon className="w-12 h-12 text-orange-500 animate-spin-slow" />
              </div>
            </div>

            {/* Title */}
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
              Analyzing Your Website
            </h2>

            {/* Progress Steps */}
            <div className="space-y-4 mb-6">
              {steps.map((step, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-3 p-4 rounded-lg transition-all ${
                    index <= currentStep ? 'bg-gray-50' : 'bg-white'
                  }`}
                >
                  <div
                    className={`w-3 h-3 rounded-full ${
                      index <= currentStep ? step.bgColor : 'bg-gray-300'
                    }`}
                  />
                  <span
                    className={`font-medium ${
                      index <= currentStep ? step.color : 'text-gray-400'
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Progress Bar */}
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden mb-6">
              <div
                className="h-full bg-gradient-to-r from-orange-500 via-green-500 to-blue-500 transition-all duration-1000"
                style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              />
            </div>

            {/* Warning Text */}
            <p className="text-center text-sm text-gray-600">
              This may take a few moments. Please don't close this page.
            </p>
          </div>
        </div>
      )}

      {/* Tailwind Animations */}
      <style>
        {`
          @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }

          @keyframes spin-slow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          .animate-spin-slow { animation: spin-slow 2s linear infinite; }
        `}
      </style>
    </div>
  );
};

export default AnalyzeWebsite;
