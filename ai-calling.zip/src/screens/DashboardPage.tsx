import React from "react";
import {
  PlusIcon,
  UserGroupIcon,
  ChatBubbleLeftRightIcon,
  CpuChipIcon,
  ArrowPathIcon,
} from "@heroicons/react/24/outline";

const DashboardPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* Welcome Header */}
        <div className="mb-8 text-center lg:text-left">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2 flex items-center justify-center lg:justify-start gap-2">
            Welcome back, User! 
            <span className="inline-block text-2xl animate-wave">👋</span>
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto lg:mx-0">
            Create and manage your AI agents. Connect them to your communication channels and automate conversations.
          </p>
        </div>

        {/* Create Button */}
        <div className="flex justify-center lg:justify-end mb-8">
          <button className="px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors flex items-center gap-2">
            <PlusIcon className="w-5 h-5" />
            Create New Agent
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition">
            <div className="flex items-center gap-3 mb-2">
              <UserGroupIcon className="w-6 h-6 text-orange-500" />
              <p className="text-sm text-gray-600 font-medium">TOTAL AGENTS</p>
            </div>
            <p className="text-3xl sm:text-4xl font-bold text-orange-500">0</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition">
            <div className="flex items-center gap-3 mb-2">
              <ChatBubbleLeftRightIcon className="w-6 h-6 text-orange-500" />
              <p className="text-sm text-gray-600 font-medium">ACTIVE CONVERSATIONS</p>
            </div>
            <p className="text-3xl sm:text-4xl font-bold text-orange-500">0</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition">
            <div className="flex items-center gap-3 mb-2">
              <CpuChipIcon className="w-6 h-6 text-orange-500" />
              <p className="text-sm text-gray-600 font-medium">MESSAGES PROCESSED</p>
            </div>
            <p className="text-3xl sm:text-4xl font-bold text-orange-500">0</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition">
            <div className="flex items-center gap-3 mb-2">
              <ArrowPathIcon className="w-6 h-6 text-orange-500" />
              <p className="text-sm text-gray-600 font-medium">API CALLS</p>
            </div>
            <p className="text-3xl sm:text-4xl font-bold text-orange-500">0</p>
          </div>
        </div>

        {/* Your AI Agents Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8 lg:p-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-8 text-center lg:text-left">Your AI Agents</h2>
          
          <div className="flex flex-col items-center justify-center py-12">
            {/* Replaced RobotIcon with emoji */}
            <span className="text-6xl mb-6 animate-bounce">🤖</span>
            <p className="text-gray-600 mb-6 text-center sm:text-lg max-w-md">
              No agents yet. Create your first AI agent to get started!
            </p>
            <button className="px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors flex items-center gap-2">
              <PlusIcon className="w-5 h-5" />
              Create Your First Agent
            </button>
          </div>
        </div>

      </main>
    </div>
  );
};

export default DashboardPage;
