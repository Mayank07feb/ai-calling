import React, { useState } from 'react';
import {
  MagnifyingGlassIcon,
  FunnelIcon,
  PlusIcon,
  UserGroupIcon,
  CheckCircleIcon,
  PhoneIcon,
  CurrencyDollarIcon,
} from '@heroicons/react/24/outline';

const MyAgentsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6 lg:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center gap-2 mb-2">
            <UserGroupIcon className="w-6 h-6 sm:w-8 sm:h-8 text-orange-500" />
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900">My AI Agents</h1>
          </div>
          <p className="text-gray-600 text-sm sm:text-base">Manage and monitor your intelligent receptionists</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-6 sm:mb-8">
          <div className="bg-white rounded-xl p-3 sm:p-4 lg:p-6 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-3 mb-2">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <UserGroupIcon className="w-4 h-4 sm:w-6 sm:h-6 text-orange-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm text-gray-600 truncate">Total Agents</p>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-orange-500">0</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-3 sm:p-4 lg:p-6 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-3 mb-2">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <CheckCircleIcon className="w-4 h-4 sm:w-6 sm:h-6 text-green-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm text-gray-600 truncate">Active Agents</p>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-orange-500">0</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-3 sm:p-4 lg:p-6 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-3 mb-2">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <PhoneIcon className="w-4 h-4 sm:w-6 sm:h-6 text-purple-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm text-gray-600 truncate">Total Calls</p>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-orange-500">0</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-3 sm:p-4 lg:p-6 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-3 mb-2">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <CurrencyDollarIcon className="w-4 h-4 sm:w-6 sm:h-6 text-yellow-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm text-gray-600 truncate">Revenue Saved</p>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-orange-500">$0</p>
              </div>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 mb-4 sm:mb-6">
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <div className="flex-1 relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-orange-500 w-4 h-4 sm:w-5 sm:h-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search agents, businesses..."
                className="w-full pl-9 sm:pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm sm:text-base"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <select className="px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm sm:text-base">
                <option>All Status</option>
              </select>
              <button className="px-3 sm:px-4 py-2 text-orange-500 font-medium flex items-center justify-center gap-2 hover:bg-orange-50 rounded-lg text-sm sm:text-base">
                <FunnelIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                <span className="hidden sm:inline">Apply Filters</span>
                <span className="sm:hidden">Filters</span>
              </button>
              <button className="px-4 sm:px-6 py-2 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors flex items-center justify-center gap-2 text-sm sm:text-base">
                <PlusIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                <span className="hidden sm:inline">Create New Agent</span>
                <span className="sm:hidden">New Agent</span>
              </button>
            </div>
          </div>
        </div>

        {/* Agents Table */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {/* Desktop Table */}
          <div className="hidden lg:block">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">AGENT</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">STATUS</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">CAPABILITIES</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">CREATED</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan={5} className="px-6 py-32 text-center">
                    <div className="flex flex-col items-center justify-center">
                      <UserGroupIcon className="w-16 h-16 text-orange-500 mb-4" />
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">No Agents Found</h3>
                      <p className="text-gray-600 mb-6 max-w-md">
                        You haven't created any AI agents yet. Get started by creating your first intelligent receptionist.
                      </p>
                      <button className="px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors flex items-center gap-2">
                        <PlusIcon className="w-5 h-5" />
                        Create Your First Agent
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Mobile Cards View */}
          <div className="lg:hidden p-4">
            <div className="text-center py-16">
              <UserGroupIcon className="w-12 h-12 sm:w-16 sm:h-16 text-orange-500 mb-4 mx-auto" />
              <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">No Agents Found</h3>
              <p className="text-gray-600 mb-6 text-sm sm:text-base px-4">
                You haven't created any AI agents yet. Get started by creating your first intelligent receptionist.
              </p>
              <button className="px-4 sm:px-6 py-2 sm:py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors flex items-center justify-center gap-2 mx-auto text-sm sm:text-base">
                <PlusIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                Create Your First Agent
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default MyAgentsPage;