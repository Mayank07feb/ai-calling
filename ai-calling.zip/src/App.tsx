import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./screens/Home.js";
import Auth from "./screens/AuthPage.js";
import Dashboard from "./screens/Dashboard.js";
import MyAgents from "./screens/MyAgentsPage.js";
import ProfilePage from "./screens/ProfilePage.js";
import AnalyzeWebsite from "./screens/AnalyzeWebsite.js"; 
import ConfigureAgent from "./screens/ConfigureAgentPage.js";
import Layout from "./layouts/Layout.js";
import DashboardLayout from "./layouts/DashboardLayout.js";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public pages */}
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/auth" element={<Auth />} />
        </Route>

        {/* Dashboard pages */}
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/my-agents" element={<MyAgents />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/analyze-website" element={<AnalyzeWebsite />} /> {/* New route */}
          <Route path="/configure-agent" element={<ConfigureAgent />} />
        </Route>
      </Routes>
    </Router>
  );
}
